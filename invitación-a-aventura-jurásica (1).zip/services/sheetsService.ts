
/**
 * Checks if the SCRIPT_URL has been configured.
 * Throws an error if the URL is missing or invalid.
 */
function checkScriptUrl(scriptUrl: string | null | undefined) {
    if (!scriptUrl || scriptUrl.includes('YOUR_SCRIPT_ID_HERE') || scriptUrl.trim() === '') {
        throw new Error('La URL del script de Google no está configurada. Sigue la guía, obtén tu URL y pégala en el campo de configuración.');
    }
}

/**
 * Performs a fetch request to the Google Apps Script with detailed error handling.
 * @param {string} scriptUrl - The full URL of the Google Apps Script.
 * @param {string} body - The request body for the POST request.
 * @returns {Promise<any>} The JSON response from the script.
 */
const fetchFromScript = async (scriptUrl: string, body: string): Promise<any> => {
    checkScriptUrl(scriptUrl);
    let response;
    try {
        response = await fetch(scriptUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
            body: body,
            redirect: 'follow'
        });
    } catch (networkError) {
        console.error('Network error during fetch:', networkError);
        throw new Error('Error de red. Revisa tu conexión a internet.');
    }

    if (!response.ok) {
        console.error(`HTTP error! Status: ${response.status}`, response);
        throw new Error(`Error del servidor (código: ${response.status}). Revisa que el script esté desplegado con acceso para 'Cualquier persona'.`);
    }
    
    let data;
    try {
        data = await response.json();
    } catch (jsonError) {
        console.error('Failed to parse JSON:', jsonError);
        throw new Error('Respuesta inesperada del servidor. Revisa los permisos del despliegue del script.');
    }

    if (!data.success) {
        console.error('Google Script internal error:', data.message);
        throw new Error(`Error en el script de Google: ${data.message}`);
    }

    return data;
};


/**
 * Fetches the total number of confirmed attendees from the Google Sheet.
 * @param {string} scriptUrl - The full URL of the Google Apps Script.
 * @returns {Promise<number>} The total number of attendees.
 */
export const getTotalAttendees = async (scriptUrl: string): Promise<number> => {
    const data = await fetchFromScript(scriptUrl, 'action=getTotal');
    return data.totalAsistentes || 0;
};

/**
 * Sends a new attendance confirmation to the Google Sheet.
 * @param {string} scriptUrl - The full URL of the Google Apps Script.
 * @param {number} quantity - The number of family members attending.
 */
export const confirmAttendance = async (scriptUrl: string, quantity: number): Promise<void> => {
    await fetchFromScript(scriptUrl, `action=confirm&quantity=${quantity}`);
};
