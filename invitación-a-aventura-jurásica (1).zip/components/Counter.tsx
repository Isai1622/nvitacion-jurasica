
import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { confirmAttendance } from '../services/sheetsService';
import ConfirmationModal from './ConfirmationModal';
import JurassicCard from './JurassicCard';

type GeminiStatus = 'idle' | 'loading' | 'error' | 'success';

interface ConfirmationProps {
    scriptUrl: string;
}

const Confirmation: React.FC<ConfirmationProps> = ({ scriptUrl }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isConfirmed, setIsConfirmed] = useState(false);
    const [status, setStatus] = useState<GeminiStatus>('idle');
    const [geminiResponse, setGeminiResponse] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const [sheetError, setSheetError] = useState('');

    const isConfigured = scriptUrl && !scriptUrl.includes('YOUR_SCRIPT_ID_HERE') && scriptUrl.trim() !== '';

    useEffect(() => {
        const confirmed = localStorage.getItem('isConfirmed');
        if (confirmed) {
            setIsConfirmed(true);
            const savedResponse = localStorage.getItem('geminiResponse');
            setGeminiResponse(savedResponse || '¡Gracias por confirmar tu asistencia a la aventura!');
            setStatus('success');
        }
    }, []);

    const handleConfirm = async (familyCount: number) => {
        setIsModalOpen(false);
        setStatus('loading');
        setErrorMessage('');
        setSheetError('');
        setGeminiResponse('');

        const geminiTask = (async () => {
            if (!process.env.API_KEY) {
                throw new Error("La clave API de Gemini no está configurada.");
            }
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const prompt = `Eres un entusiasta organizador de fiestas de cumpleaños para niños con temática de dinosaurios. Genera un mensaje de confirmación muy corto, divertido y emocionante en español para un invitado que acaba de confirmar su asistencia. El cumpleañero se llama Ismael y cumple 7 años. El invitado confirmó que vendrán ${familyCount} personas. Menciona el número de personas de forma creativa (ej: "una manada de ${familyCount}...", "un equipo de ${familyCount} exploradores...", etc.). El tono debe ser alegre y jurásico. No uses más de 25 palabras.`;
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: prompt,
            });
            return response.text;
        })();

        const sheetTask = confirmAttendance(scriptUrl, familyCount);

        const [geminiResult, sheetResult] = await Promise.allSettled([geminiTask, sheetTask]);
        
        if (geminiResult.status === 'fulfilled') {
            const text = geminiResult.value;
            setGeminiResponse(text);
            setStatus('success');
            setIsConfirmed(true);
            localStorage.setItem('isConfirmed', 'true');
            localStorage.setItem('geminiResponse', text);
        } else {
            console.error('Error al generar mensaje de confirmación:', geminiResult.reason);
            setStatus('error');
            setErrorMessage(geminiResult.reason instanceof Error ? 'No se pudo generar la confirmación con IA.' : 'Ocurrió un error desconocido con la IA.');
        }

        if (sheetResult.status === 'rejected') {
            console.error('Error al guardar en Google Sheet:', sheetResult.reason);
            setSheetError('No se pudo actualizar el contador de invitados. Por favor, avisa al anfitrión.');
        }
    };

    const CheckIcon = () => (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
        </svg>
    );
    
    const renderStatusArea = () => {
        const sheetErrorMessage = sheetError ? <p className="text-yellow-400 text-xs mt-2 animate-fadeIn">{sheetError}</p> : null;

        switch (status) {
            case 'loading':
                return (
                    <div className="bg-blue-600 bg-opacity-30 p-4 rounded-lg border-2 border-blue-500">
                         <div className="flex items-center justify-center text-blue-200">
                            <svg className="animate-spin h-5 w-5 mr-3" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            <span>Generando tu pase de expedición...</span>
                        </div>
                    </div>
                );
            case 'success':
                 if (geminiResponse) {
                    return (
                        <div>
                            <div className="bg-green-600 bg-opacity-30 p-4 rounded-lg border-2 border-green-500 animate-fadeIn">
                                <p className="text-green-200 text-lg text-center font-bold">🎉 {geminiResponse} 🎉</p>
                            </div>
                            {sheetErrorMessage}
                        </div>
                    );
                 }
                 return null;
            case 'error':
                 if (errorMessage) {
                    return (
                         <div>
                            <div className="bg-red-800 bg-opacity-50 p-4 rounded-lg border-2 border-red-600">
                                <p className="text-red-200 text-lg text-center">{errorMessage}</p>
                            </div>
                            {sheetErrorMessage}
                        </div>
                    );
                 }
                 return sheetErrorMessage;
            default:
                return sheetErrorMessage;
        }
    };


    return (
        <>
            <JurassicCard>
                <h3 className="font-bangers text-5xl md:text-6xl text-amber-400 mb-4">¡Confirma tu Expedición!</h3>
                <p className="text-lg md:text-xl mb-8 text-gray-200">
                    ¡Asegura tu lugar en la aventura más grande de la prehistoria!
                </p>
                
                <div className="mb-4" {...(!isConfigured && {title: "El anfitrión necesita configurar la invitación para habilitar la confirmación."})}>
                    <button 
                        onClick={() => setIsModalOpen(true)}
                        disabled={isConfirmed || status === 'loading' || !isConfigured}
                        className="btn-jurassic text-xl mb-4 inline-flex items-center"
                    >
                       <CheckIcon /> {isConfirmed ? '¡Aventura Confirmada!' : '¡Confirmo mi Asistencia!'}
                    </button>
                    {!isConfigured && !isConfirmed && <p className="text-xs text-yellow-400 mt-2">La confirmación está desactivada hasta que el anfitrión termine la configuración.</p>}
                </div>
                
                <div className="h-24 flex items-center justify-center p-2">
                    {renderStatusArea()}
                </div>
            </JurassicCard>

            <ConfirmationModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onConfirm={handleConfirm}
            />
        </>
    );
};

export default Confirmation;
