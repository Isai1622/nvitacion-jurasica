
import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import MainContent from './components/MainContent';
import Footer from './components/Footer';
import BackgroundEffects from './components/BackgroundEffects';

function App() {
  const [showConfetti, setShowConfetti] = useState(true);
  const [scriptUrl, setScriptUrl] = useState<string>('');

  useEffect(() => {
    // Hide initial confetti after a while to not be too distracting
    const timer = setTimeout(() => setShowConfetti(false), 15000);
    
    // Load the saved script URL from localStorage
    const savedUrl = localStorage.getItem('jurassicScriptUrl');
    if (savedUrl) {
      setScriptUrl(savedUrl);
    }

    return () => clearTimeout(timer);
  }, []);

  const handleSaveUrl = (url: string) => {
    localStorage.setItem('jurassicScriptUrl', url);
    setScriptUrl(url);
    // Optionally, force a reload or a state update in child components
    window.location.reload(); 
  };


  return (
    <div className="text-white relative">
      <BackgroundEffects showInitialConfetti={showConfetti} />
      <Header />
      <MainContent 
        scriptUrl={scriptUrl}
        onSaveUrl={handleSaveUrl}
      />
      <Footer />
    </div>
  );
}

export default App;
